asmlinkage long sys_cs300_test(int argument);
